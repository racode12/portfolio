﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form2 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        MySqlConnection con1 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form2()
        {
            InitializeComponent();
        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Form1 loginform = new Form1();
            loginform.Show();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Form3 editform = new Form3();
            editform.Show();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Form3 n3 = new Form3();
            n3.Show();
            this.Hide();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            Form4 n4 = new Form4();
            n4.Show();
            this.Hide();
        }
       
        private void button11_Click(object sender, EventArgs e)
        {
            Form6 n6 = new Form6();
            n6.Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form7 n7 = new Form7();
            n7.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 n8 = new Form8();
            n8.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form9 n9 = new Form9();
            n9.Show();
            this.Hide();
        }
    
    }
}
