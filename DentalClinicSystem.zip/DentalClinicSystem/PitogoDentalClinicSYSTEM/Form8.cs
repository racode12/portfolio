﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form8 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form8()
        {
            InitializeComponent();
        }

        public void load0()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName as 'Last Name',firstName as 'First Name',Age,Sex,Address,contactNo FROM patientinfo WHERE lastName LIKE '%" + textBox4.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }
        public void load1()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName as 'Last Name',firstName as 'First Name',Age,Sex,Address,contactNo FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Form2 n2 = new Form2();
            n2.Show();
            this.Dispose();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName as 'Last Name',firstName as 'First Name',Age,Sex,Address,contactNo FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectrow = dataGridView1.Rows[index];
            textBox3.Text = selectrow.Cells[0].Value.ToString();
            textBox1.Text = selectrow.Cells[1].Value.ToString();
            textBox2.Text = selectrow.Cells[2].Value.ToString();
            textBox5.Text = selectrow.Cells[3].Value.ToString();
            comboBox3.Text = selectrow.Cells[4].Value.ToString();
            textBox7.Text = selectrow.Cells[5].Value.ToString();
            textBox8.Text = selectrow.Cells[6].Value.ToString();
            

            button6.Enabled = true;
            button3.Enabled = true;

            textBox1.ReadOnly = false;
            textBox2.ReadOnly = false;
            textBox3.ReadOnly = false;
            textBox5.ReadOnly = false;
            comboBox3.Enabled = true;
            textBox7.ReadOnly = false;
            textBox8.ReadOnly = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {

            string query = "UPDATE patientinfo SET lastName = '" + textBox1.Text + "', firstName = '" + textBox2.Text + "', Age = '"+textBox5.Text+"', Sex = '"+comboBox3.Text+"', Address = '"+textBox7.Text+"', contactNo = '"+textBox8.Text+"' WHERE patientID = '" + textBox3.Text + "'";
            MySqlCommand cmd0 = new MySqlCommand(query, con0);
            MySqlDataReader reader0;
            con0.Open();
            reader0 = cmd0.ExecuteReader();
            while (reader0.Read())
            {
            }
            con0.Close();
      
            MessageBox.Show("Update Success");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
            comboBox3.Text = "";
            textBox7.Clear();
            textBox8.Clear();

            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox5.ReadOnly = true;
            comboBox3.Enabled = false;
            textBox7.ReadOnly = true;
            textBox8.ReadOnly = true;

            button6.Enabled = false;
            button3.Enabled = false;
            load0();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
            comboBox3.Text = "";
            textBox7.Clear();
            textBox8.Clear();

            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox5.ReadOnly = true;
            comboBox3.Enabled = false;
            textBox7.ReadOnly = true;
            textBox8.ReadOnly = true;

            button6.Enabled = false;
            button3.Enabled = false;
        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName as 'Last Name',firstName as 'First Name',Age,Sex,Address,contactNo FROM patientinfo WHERE lastName LIKE '%" + textBox4.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }
    }
}
