﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form3 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Form2 mainform = new Form2();
            mainform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if(textBox12.Text == "")
            //{
            //    MessageBox.Show("Please fill-up all the blank");
            //}
            //else
            //{
            //MySqlCommand cmd0 = new MySqlCommand("INSERT INTO patienttb(Lastname,Firstname,Middlename,Dateofbirth,Placeofbirth,Address,Occupation,Parentorguardian,Medicalhistory,hcID,serviceID,paymentID)VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "')", con0);
            //MySqlDataReader reader0;
            //con0.Open();
            //reader0 = cmd0.ExecuteReader();
            //MessageBox.Show("Add Patient successfully");
            //while(reader0.Read())
            //{
            //}
            //con0.Close();
            //}
        }

  
        private void button4_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Form2 mainform = new Form2();
            mainform.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 n2 = new Form2();
            n2.Show();
            this.Dispose();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(textBox1.Text != "" || textBox2.Text != "" || textBox3.Text != "" || textBox5.Text != "" || textBox6.Text != "" || comboBox1.Text != "")
            {
            MySqlCommand cmd0 = new MySqlCommand("INSERT INTO patientinfo(lastName,firstName,Age,Sex,Address,contactNo,dateReg)VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','"+textBox4.Text+"')", con0);
            MySqlDataReader reader0;
            con0.Open();
            reader0 = cmd0.ExecuteReader();
            MessageBox.Show("Add Patient successfully");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox1.Text = "";
            while(reader0.Read())
            {
            }
            con0.Close();
            }
            else
            {
            MessageBox.Show("Please fill-up all this form");
            }
}

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox1.Text = "";
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            textBox4.Text = time.ToShortDateString();
            //textBox4.Text = time.ToString("hh:mm:ss tt");
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
