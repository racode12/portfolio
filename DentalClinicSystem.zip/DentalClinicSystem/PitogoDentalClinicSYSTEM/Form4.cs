﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form4 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form4()
        {
            InitializeComponent();
        }

        DataTable table1 = new DataTable();

        public void load0()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName,dateApt,Time FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }
        public void load1()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName,dateApt,Time FROM patientinfo WHERE serviceName LIKE '%" + comboBox2.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        public void load2()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName,dateApt,Time FROM patientinfo WHERE serviceName = '" + comboBox2.Text + "' AND lastName LIKE '%" + textBox4.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 n2 = new Form2();
            n2.Show();
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {


                    string query0 = "UPDATE patientinfo SET serviceName = '" + string.Concat(textBox5.Text,"/ ",textBox13.Text,"/ ",textBox14.Text,"/ ",textBox15.Text,"/ ",textBox16.Text,"/ ",textBox17.Text) 
                        + "', dateApt = '" + dateTimePicker1.Text + "', Time = '" + comboBox1.Text + "', totalPrice = '"+textBox6.Text+"' WHERE patientID = '" + textBox3.Text + "'";
                    MySqlCommand cmd0 = new MySqlCommand(query0, con0);
                    MySqlDataReader reader0;
                    con0.Open();
                    reader0 = cmd0.ExecuteReader();
                    while (reader0.Read())
                    {
                    }
                    con0.Close();




            MessageBox.Show("Scheduled Success");
            
            dateTimePicker1.Value = DateTime.Now;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox17.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;

            comboBox1.Text = "";

            button1.Enabled = false;
            //button3.Enabled = false;
            button4.Enabled = false;


            //textBox5.Clear();
            //textBox6.Clear();
            //table1.Rows.Clear();
            //dataGridView2.DataSource = table1;


            //button1.Enabled = false;
            //button3.Enabled = false;
            //button4.Enabled = false;
            //textBox1.Clear();
            //textBox2.Clear();
            //textBox3.Clear();
            //checkedListBox1.SetItemChecked(0, false);
            //checkedListBox1.SetItemChecked(1, false);
            //checkedListBox1.SetItemChecked(2, false);
            //checkedListBox1.SetItemChecked(3, false);
            //checkedListBox1.SetItemChecked(4, false);
            //checkedListBox1.SetItemChecked(5, false);
            //comboBox1.Text = "";
            load0();
                
               
           
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName,dateApt,Time FROM patientinfo", con0);
          
            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectrow = dataGridView1.Rows[index];
            textBox3.Text = selectrow.Cells[0].Value.ToString();
            textBox1.Text = selectrow.Cells[1].Value.ToString();
            textBox2.Text = selectrow.Cells[2].Value.ToString();

            button4.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
        
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
                //checkedListBox1.SetItemChecked(0, false);
                //checkedListBox1.SetItemChecked(1, false);
                //checkedListBox1.SetItemChecked(2, false);
                //checkedListBox1.SetItemChecked(3, false);
                //checkedListBox1.SetItemChecked(4, false);
                //checkedListBox1.SetItemChecked(5, false);
                comboBox1.Text = "";

                button1.Enabled = false;
                //button3.Enabled = false;
                button4.Enabled = false;
          

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "UPDATE patientinfo SET serviceName = null , dateApt = null, Time = null, totalPrice = null WHERE patientID = '" + textBox3.Text + "'";
            MySqlCommand cmd0 = new MySqlCommand(query, con0);
            MySqlDataReader reader0;
            con0.Open();
            reader0 = cmd0.ExecuteReader();
            while (reader0.Read())
            {
            }
            con0.Close();
            MessageBox.Show("Schedule Removed");
            load0();
            button1.Enabled = false;
            //button3.Enabled = false;
            button4.Enabled = false;

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox17.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName,dateApt,Time FROM patientinfo WHERE lastName LIKE '%" + textBox4.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);

            if(comboBox2.SelectedIndex == 0)
            {
                load2();
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                load2();
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                load2();
            }
            else if (comboBox2.SelectedIndex == 3)
            {
                load2();
            }
            else if (comboBox2.SelectedIndex == 4)
            {
                load2();
            }
            else if (comboBox2.SelectedIndex == 5)
            {
                load2();
            }

           
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = null;
            comboBox2.Text = "services";
            load0();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox2.SelectedIndex == 0)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 3)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 4)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 5)
            {
                load1();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

            if (dateTimePicker1.Value > DateTime.Now)
            {
                button1.Enabled = true;
                button3.Enabled = true;
                //button4.Enabled = true;

            }
            else if (dateTimePicker1.Value == DateTime.Now)
            {
                button1.Enabled = true;
                button3.Enabled = true;
                //button4.Enabled = true;

            }
            else if (dateTimePicker1.Value < DateTime.Now)
            {
               
                dateTimePicker1.Value = DateTime.Now;
                MessageBox.Show("You cannot schedule on previous date.");
                button1.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
            else
            {
                button1.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                textBox7.Text = "50.00";
                textBox5.Text = "Temporary Filling";
            }
            else
            {
                textBox7.Text = "0.00";
                textBox5.Text = "";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                textBox8.Text = "150.00";
                textBox13.Text = "Permanent Filling";
            }
            else
            {
                textBox8.Text = "0.00";
                textBox13.Text = "";
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                textBox9.Text = "250.00";
                textBox14.Text = "Light Cure Filling";
            }
            else
            {
                textBox9.Text = "0.00";
                textBox14.Text = "";
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                textBox10.Text = "200.00";
                textBox15.Text = "Extraction";
            }
            else
            {
                textBox10.Text = "0.00";
                textBox15.Text = "";
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                textBox11.Text = "50.00";
                textBox16.Text = "Oralprophylaxis";
            }
            else
            {
                textBox11.Text = "0.00";
                textBox16.Text = "";
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                textBox12.Text = "200.00";
                textBox17.Text = "Gum Treatment";
            }
            else
            {
                textBox12.Text = "0.00";
                textBox17.Text = "";
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString() +".00";
            }
            catch(FormatException)
            {
          
            }

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString();
            }
            catch (FormatException)
            {

            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString();
            }
            catch (FormatException)
            {

            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString();
            }
            catch (FormatException)
            {

            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString();
            }
            catch (FormatException)
            {

            }
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString();
            }
            catch (FormatException)
            {

            }
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double v1 = Convert.ToDouble(textBox7.Text);
                double v2 = Convert.ToDouble(textBox8.Text);
                double v3 = Convert.ToDouble(textBox9.Text);
                double v4 = Convert.ToDouble(textBox10.Text);
                double v5 = Convert.ToDouble(textBox11.Text);
                double v6 = Convert.ToDouble(textBox12.Text);

                double total = v1 + v2 + v3 + v4 + v5 + v6;
                textBox6.Text = total.ToString();
            }
            catch (FormatException)
            {

            }
        }

       


    }
}
