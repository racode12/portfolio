﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form6 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form6()
        {
            InitializeComponent();
        }
        public void load0()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID as 'Patient ID',lastName as 'Last Name',firstName as 'First Name',serviceName as 'Services', totalPrice as 'Total Amount' FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }
        public void load1()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID as 'Patient ID',lastName as 'Last Name',firstName as 'First Name',serviceName as 'Services', totalPrice as 'Total Amount' FROM patientinfo WHERE serviceName LIKE '%" + comboBox2.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectrow = dataGridView1.Rows[index];
            textBox3.Text = selectrow.Cells[0].Value.ToString();
            textBox1.Text = selectrow.Cells[1].Value.ToString();
            textBox2.Text = selectrow.Cells[2].Value.ToString();
            textBox7.Text = selectrow.Cells[3].Value.ToString();
            textBox8.Text = selectrow.Cells[4].Value.ToString();
            textBox5.Text = selectrow.Cells[4].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 n2 = new Form2();
            n2.Show();
            this.Dispose();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
                try
                {
                    double v1 = Convert.ToDouble(textBox5.Text);
                    double v2 = Convert.ToDouble(textBox4.Text);
                    double total = v2 - v1;

                    if (v2 <= v1)
                    {
                        textBox6.Text = "0.00";
                    }
                    else
                    {
                        textBox6.Text = total.ToString();
                    }
                    
                }
                catch (FormatException)
                {
                    if (string.IsNullOrEmpty(textBox4.Text))
                    {
                        if (textBox4.Text == "")
                        {
                            textBox4.Text = "0.00";
                            textBox6.Text = "0.00";
                        }
                    }
                }
            

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID as 'Patient ID',lastName as 'Last Name',firstName as 'First Name',serviceName as 'Services', totalPrice as 'Total Amount' FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);

            DateTime time = DateTime.Now;
            label12.Text = time.ToShortDateString();
            label9.Text = time.ToString("hh:mm:ss tt");
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            if (textBox7.Text == "Temporary Filling")
            {
                textBox8.Text = "50.00";
                textBox5.Text = textBox8.Text;
            }
            else if (textBox7.Text == "Permanent Filling")
            {
                textBox8.Text = "150.00";
                textBox5.Text = textBox8.Text;
            }
            else if (textBox7.Text == "Light Cure Filling")
            {
                textBox8.Text = "250.00";
                textBox5.Text = textBox8.Text;
            }
            else if (textBox7.Text == "Oral Prophylaxis")
            {
                textBox8.Text = "200.00";
                textBox5.Text = textBox8.Text;
            }
            else if (textBox7.Text == "Extraction")
            {
                textBox8.Text = "50.00";
                textBox5.Text = textBox8.Text;
            }
            else if (textBox7.Text == "Gum Treatment")
            {
                textBox8.Text = "200.00";
                textBox5.Text = textBox8.Text;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            double v1 = Convert.ToDouble(textBox4.Text);
            double v2 = Convert.ToDouble(textBox5.Text);


            if(v1 <= v2 )
            {
                MessageBox.Show("Sorry, you cannot process");
            }
            else
            {
                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            }         
        }

        private void button3_Click(object sender, EventArgs e)
        {         
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Text = "0.00";
            textBox6.Text = "0.00";
            textBox7.Clear();
            textBox8.Text = "0.00";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 3)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 4)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 5)
            {
                load1();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID as 'Patient ID',lastName as 'Last Name',firstName as 'First Name',serviceName as 'Services', totalPrice as 'Total Amount' FROM patientinfo WHERE serviceName = '" + comboBox2.Text + "' AND lastName LIKE '%" + textBox9.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            comboBox2.Text = "services";
            load0();
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("PITOGO DENTAL CLINIC", new Font("Arial", 20, FontStyle.Bold), Brushes.OrangeRed, new Point(25, 50));
            e.Graphics.DrawString("Address: Brgy.Pitogo District II Makati City", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 85));
            e.Graphics.DrawString("Phone: 661-6596", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 105));
            e.Graphics.DrawString("Email: pitogodental@gmail.com", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 120));


            e.Graphics.DrawString("Patient Name: "+textBox1.Text+", "+textBox2.Text, new Font("Arial",12, FontStyle.Regular),Brushes.Black, new Point(25,180));
            e.Graphics.DrawString("Date: " + DateTime.Now, new Font("Arial", 12), Brushes.Black, new Point(25, 200));
            
            e.Graphics.DrawString(label13.Text, new Font("Arial", 12), Brushes.Black, new Point(25, 255));
            e.Graphics.DrawString("Service Description: ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 280));
            e.Graphics.DrawString("Fee: ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(500, 280));
            e.Graphics.DrawString(label14.Text, new Font("Arial", 12), Brushes.Black, new Point(25, 295));

            e.Graphics.DrawString(textBox7.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 320));
            e.Graphics.DrawString(textBox8.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(500, 320));

            e.Graphics.DrawString(label14.Text, new Font("Arial", 12), Brushes.Black, new Point(25, 550));
            e.Graphics.DrawString("Cash: ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 580));
            e.Graphics.DrawString(textBox4.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(500, 580));
            e.Graphics.DrawString("Total Amount: " , new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 600));
            e.Graphics.DrawString(label15.Text, new Font("Arial", 12), Brushes.Black, new Point(490, 600));
            e.Graphics.DrawString("Change: ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 620));
            e.Graphics.DrawString(textBox6.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(500, 620));
            e.Graphics.DrawString(label14.Text, new Font("Arial", 12), Brushes.Black, new Point(25, 630));

            e.Graphics.DrawString(textBox5.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(500, 600));

            e.Graphics.DrawString("Process by: Dr.Antonio M. Pizon, Jr", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(290, 800));
            e.Graphics.DrawString("- THIS IS YOUR OFFICIAL RECEIPT -", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(280, 830));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (textBox8.Text == "")
            {
                textBox8.Text = "0.00";
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "0.00";
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
