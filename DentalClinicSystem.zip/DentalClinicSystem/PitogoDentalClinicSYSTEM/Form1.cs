﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form1 : Form
    {
        MySqlConnection con = new MySqlConnection("Datasource=localhost;port=3306;Database=inventorydb;Uid=root;Pwd=1234;");
        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT type FROM users WHERE username = '"+textBox1.Text+"'AND password = '"+textBox2.Text+"'",con);
            MySqlDataReader reader;

            con.Open();
            reader = cmd.ExecuteReader();
            string uType = "";
            while(reader.Read())
            {
                uType = reader.GetString(0);                         
            }
            con.Close();
            if (uType == "Admin")
            {
                this.Hide();
                Form2 main = new Form2();
                main.Show();
            }
            else
            {
                MessageBox.Show("Wrong username or password!");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = "";
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            textBox2.Text = "";
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = "username";
            textBox2.Text = "password";
            textBox2.UseSystemPasswordChar = false;
        }
    }
}
