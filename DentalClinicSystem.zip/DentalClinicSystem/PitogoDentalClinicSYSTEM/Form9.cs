﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form9 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form9()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 n2 = new Form2();
            n2.Show();
            this.Dispose();
        }
        public void load0()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT * FROM usertb", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }
        private void Form9_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT * FROM usertb", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT * FROM usertb WHERE userType = '"+comboBox1.Text+"' AND username LIKE '%"+textBox4.Text+"%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel3.Visible = false;
            dataGridView1.Enabled = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel3.Visible = true;
            dataGridView1.Enabled = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
             MySqlCommand cmd0 = new MySqlCommand("INSERT INTO usertb(username,password,userType)VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox3.Text + "')", con0);
            MySqlDataReader reader0;
            con0.Open();
            reader0 = cmd0.ExecuteReader();   
            while(reader0.Read())
            {
            }
            con0.Close();
            MessageBox.Show("Add User Successfully");
            load0();
            textBox1.Clear();
            textBox2.Clear();
            comboBox3.Text = "";
        }

        private void button8_Click(object sender, EventArgs e)
        {
             string query = "UPDATE usertb SET username = '" + textBox3.Text + "', password = '" + textBox5.Text + "' WHERE userID = '"+textBox6.Text+"'";
                    MySqlCommand cmd0 = new MySqlCommand(query,con0);
                    MySqlDataReader reader0;
                    con0.Open();
                    reader0 = cmd0.ExecuteReader();
                    while (reader0.Read())
                    {
                    }
                    con0.Close();                 
            MessageBox.Show("Update User Successfully");
            load0();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            comboBox3.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel3.Visible = false;
            textBox1.Clear();
            textBox2.Clear();
            comboBox3.Text = "";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel3.Visible = false;
            textBox3.Clear();
            textBox5.Clear();
            comboBox2.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox5.Clear();
            comboBox2.Text = "";
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectrow = dataGridView1.Rows[index];
            textBox6.Text = selectrow.Cells[0].Value.ToString();
            textBox3.Text = selectrow.Cells[1].Value.ToString();
            textBox5.Text = selectrow.Cells[2].Value.ToString();
            comboBox2.Text = selectrow.Cells[3].Value.ToString();

            textBox6.Enabled = true;
            textBox3.Enabled = true;
            textBox5.Enabled = true;
            comboBox2.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT * FROM usertb WHERE userType = '"+comboBox1.Text+"'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
