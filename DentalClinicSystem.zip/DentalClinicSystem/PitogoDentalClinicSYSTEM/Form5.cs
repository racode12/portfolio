﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PitogoDentalClinicSYSTEM
{
    public partial class Form5 : Form
    {
        MySqlConnection con0 = new MySqlConnection("Datasource=localhost;port=3306;Database=pitogodb;Uid=root;Pwd=1234;");
        public Form5()
        {
            InitializeComponent();
        }
        public void load0()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }
        public void load1()
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName FROM patientinfo WHERE serviceName LIKE '%" + comboBox2.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Form2 n2 = new Form2();
            n2.Show();
            this.Dispose();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName FROM patientinfo", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectrow = dataGridView1.Rows[index];
            textBox3.Text = selectrow.Cells[0].Value.ToString();
            textBox1.Text = selectrow.Cells[1].Value.ToString();
            textBox2.Text = selectrow.Cells[2].Value.ToString();
            textBox7.Text = selectrow.Cells[3].Value.ToString();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            if(textBox7.Text == "Temporary Filling")
            {
                textBox8.Text = "50";
                textBox5.Text = textBox8.Text;
            }
            else if(textBox7.Text == "Permanent Filling")
            {
                textBox8.Text = "150";
                textBox5.Text = textBox8.Text;
            }
            else if(textBox7.Text == "Light Cure Filling")
            {
                textBox8.Text = "250";
                textBox5.Text = textBox8.Text;
            }
            else if(textBox7.Text == "Oral Prophylaxis")
            {
                textBox8.Text = "200";
                textBox5.Text = textBox8.Text;
            }
            else if(textBox7.Text == "Extraction")
            {
                textBox8.Text = "50";
                textBox5.Text = textBox8.Text;
            }
            else if (textBox7.Text == "Gum Treatment")
            {
                textBox8.Text = "200";
                textBox5.Text = textBox8.Text;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 3)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 4)
            {
                load1();
            }
            else if (comboBox2.SelectedIndex == 5)
            {
                load1();
            }
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            comboBox2.Text = "services";
            load0();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd0 = new MySqlCommand("SELECT patientID,lastName,firstName,serviceName FROM patientinfo WHERE serviceName = '" + comboBox2.Text + "' AND lastName LIKE '%" + textBox4.Text + "%'", con0);

            MySqlDataAdapter da0 = new MySqlDataAdapter();
            da0.SelectCommand = cmd0;
            DataTable table0 = new DataTable();
            da0.Fill(table0);
            BindingSource bs0 = new BindingSource();
            bs0.DataSource = table0;
            dataGridView1.DataSource = bs0;
            da0.Update(table0);
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

  
    }
}
